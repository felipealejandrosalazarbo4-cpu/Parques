using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ParquésUI
{
    public class Form1 : Form
    {
        // numero de jugadores en juego (siempre 4)
        List<Jugador> jugadores = new List<Jugador>();

        // numero casillas
        List<Point> casillas = new List<Point>();
         
        // ejecucion del dado
        Random rng = new Random();

        // orden jugadores 
        int turno = 0;

        // forma de juego todos empiezan en 0 y el primero en llegar a la ultima casilla gana
        Button btnDado = new Button();

        Label lblTurno = new Label();

        Label lblDado = new Label();

        public Form1()
        {
            // nombre juego
            this.Text = "Parqués Básico";
            this.Size = new Size(900, 700);
            this.BackColor = Color.White;

            InicializarUI();

            CrearTablero();

            CrearJugadores();

            ActualizarTurno();
        }

        void InicializarUI()    
        {
            // texto del jugador en turno
            lblTurno.Location = new Point(30, 30);
            lblTurno.AutoSize = true;
            lblTurno.Font = new Font("Arial", 14);

            this.Controls.Add(lblTurno);

            // texto dado
            lblDado.Location = new Point(30, 70);
            lblDado.AutoSize = true;
            lblDado.Font = new Font("Arial", 14);

            this.Controls.Add(lblDado);

            // dado
            btnDado.Text = "Lanzar dado";
            btnDado.Size = new Size(140, 50);
            btnDado.Location = new Point(30, 120);

            btnDado.Click += BtnDado_Click;

            this.Controls.Add(btnDado);
        }

        void CrearTablero()
        {
            casillas.Clear();

            int tamaño = 50;

            // x superior
            for (int x = 250; x <= 600; x += tamaño)
            {
                casillas.Add(new Point(x, 100));
            }

            // y derecha
            for (int y = 150; y <= 500; y += tamaño)
            {
                casillas.Add(new Point(600, y));
            }

            // x baja
            for (int x = 550; x >= 250; x -= tamaño)
            {
                casillas.Add(new Point(x, 500));
            }

            // y izquierda
            for (int y = 450; y >= 150; y -= tamaño)
            {
                casillas.Add(new Point(250, y));
            }

            // representa el tablero
            for (int i = 0; i < casillas.Count; i++)
            {
                Panel casilla = new Panel();

                casilla.Size = new Size(45, 45);

                casilla.Location = casillas[i];

                casilla.BackColor = Color.LightGray;

                casilla.BorderStyle = BorderStyle.FixedSingle;

                Label numero = new Label();

                numero.Text = i.ToString();

                numero.AutoSize = true;

                numero.Location = new Point(12, 12);

                casilla.Controls.Add(numero);

                this.Controls.Add(casilla);

                // acomodar casillas en orden
                casilla.SendToBack();
            }
        }

        void CrearJugadores()
        {
            jugadores.Add(new Jugador("Rojo", Color.Red));

            jugadores.Add(new Jugador("Azul", Color.Blue));

            jugadores.Add(new Jugador("Verde", Color.Green));

            jugadores.Add(new Jugador("Amarillo", Color.Gold));

            for (int i = 0; i < jugadores.Count; i++)
            {
                PictureBox ficha = new PictureBox();

                ficha.Size = new Size(18, 18);

                ficha.BackColor = jugadores[i].Color;

                ficha.BorderStyle = BorderStyle.FixedSingle;

                ficha.Location = ObtenerPosicionFicha(0, i);

                this.Controls.Add(ficha);

                ficha.BringToFront();

                jugadores[i].Ficha = ficha;
            }
        }

        private void BtnDado_Click(object sender, EventArgs e)
        {
            // jugador en juego
            Jugador actual = jugadores[turno];

            // lanzar dado
            int dado = rng.Next(1, 7);

            lblDado.Text = "Dado: " + dado;

            // el jugador se mueve el numero sacado
            actual.Posicion += dado;

            // al jugador ganador se le asigna la ultima casilla y se muestra un mensaje de ganador y se desactiva el boton de dado
            if (actual.Posicion >= casillas.Count)
            {
                actual.Posicion = casillas.Count - 1;

                MoverFicha(actual);

                MessageBox.Show(actual.Nombre + " ganó");

                btnDado.Enabled = false;

                return;
            }

            // muestra la posicion en que esta
            MoverFicha(actual);

            // siguiente persona
            turno++;

            if (turno >= jugadores.Count)
            {
                turno = 0;
            }

            ActualizarTurno();
        }

        void MoverFicha(Jugador jugador)
        {
            int indice = jugadores.IndexOf(jugador);

            jugador.Ficha.Location =
                ObtenerPosicionFicha(jugador.Posicion, indice);

            jugador.Ficha.BringToFront();
        }
        Point ObtenerPosicionFicha(int posicion, int indiceJugador)
        {
            Point basePosicion = casillas[posicion];

            int offsetX = 0;
            int offsetY = 0;

            // cada posicion es diferente para los jugadores en caso de que sea la misma casilla se obucaran en oreden de salida
            switch (indiceJugador)
            {
                case 0:
                    offsetX = 5;
                    offsetY = 5;
                    break;

                case 1:
                    offsetX = 22;
                    offsetY = 5;
                    break;

                case 2:
                    offsetX = 5;
                    offsetY = 22;
                    break;

                case 3:
                    offsetX = 22;
                    offsetY = 22;
                    break;
            }

            return new Point(
                basePosicion.X + offsetX,
                basePosicion.Y + offsetY
            );
        }
        void ActualizarTurno()
        {
            lblTurno.Text =
                "Turno de: " +
                jugadores[turno].Nombre;
        }

       
    }

    public class Jugador
    {
        public string Nombre;

        public int Posicion;

        public Color Color;

        public PictureBox Ficha;

        public Jugador(string nombre, Color color)
        {
            Nombre = nombre;

            Color = color;

            Posicion = 0;
        }
    }
}